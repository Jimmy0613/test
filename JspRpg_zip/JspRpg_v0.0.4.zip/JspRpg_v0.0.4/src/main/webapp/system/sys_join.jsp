<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<div id="s_info">
		<div id="c_mode">&nbsp;&nbsp;📝 가입 </div>
	</div>
	<div id="s_menu_right_t">메뉴</div>
	<div id="s_content">
		<form action="../proc/joinProc.jsp">
			<p id="form_i">
				<br>&nbsp;<b> 아이디*</b> &nbsp;&nbsp; <input name="id"
					placeholder=" 6~12자" maxlength="12" required> <br>&nbsp;
				<b>비밀번호* </b> <input name="pw1" type="password" placeholder=" 8~14자"
					maxlength="14" required> <br>&nbsp; <b> &nbsp;
					ㄴ확인* </b>&nbsp;<input name="pw2" type="password" placeholder=" 비밀번호 확인"
					maxlength="14" required> <br> &nbsp; <b> 닉네임* </b>&nbsp;&nbsp;&nbsp;
				<input type="text" name="m_name" placeholder=" 2~6자" maxlength="6"
					required> <br>&nbsp; <b> 이메일 </b>&nbsp; <input
					name="email1"> <b>@</b> <input name="email2"> <br><b
					id="form_w">&nbsp;&nbsp;* 표시가 붙은 항목은 필수 입력 항목입니다.</b> <br>
				<br>
				<button type="submit" class="btn">가입하기</button>
			</p>
		</form>
	</div>
	<div id="s_menu_right">
		<div class="icon" id="icon1">
			<a href="../index.jsp"><img src="../img/home.png"></a>
		</div>
		<b class="icon_t" id="icon1_t">홈</b>
		
		<div class="icon" id="icon2">
			<a href="../login.jsp"><img src="../img/login.png"></a>
		</div>
		<b class="icon_t" id="icon2_t">로그인</b>
		
	</div>
	<div id="s_banner_bot">
		🙂 먼저 로그인해주세요.
	</div>

</body>
</html>
