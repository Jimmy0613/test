<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>복도</title>
<link rel="stylesheet" href="../css/m_2.css">

</head>
<body>
	<%
	Charac character = new Charac();
	Log log = new Log();
	Map map_i = new Map();
	map_i.load(request.getParameter("m_id"));
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w">
		<%
		if (Charac.player.getStory() >= map_i.getOpenStory(Map.currentMap.getMapWest())) {
		%>
		<button id="we_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.currentMap.getMapWest()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapWest())%></button>
		<%
		}
		%>
	</div>
	<div id="screen_c">
		<!------------------스크린 ------------------>
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
			if (Charac.player.getStory() < 1) {
				log.send(Charac.player.getName() + "🗣 \"으악 쥐다!\"", "speech");
				Log.turnCount++;
				log.send("[ " + Log.turnCount + " ] 쥐를 보고 놀라 힘이 빠졌습니다. (힘 -2)", "normal");
				log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +5) ", "story");
				Charac.player.setExp(Charac.player.getExp() + 5);
				Charac.player.setPower(Charac.player.getPower() - 2);
				Charac.player.setStory(1);
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action1" name="mode" />
			<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
		</jsp:forward>
		<%
		} else if (Charac.player.getStory() < 2) {
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action1" name="mode" />
			<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
		</jsp:forward>
		<%
		}
		%>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
		%><div id="player">
			<img src="img/humansurprised.jpg" id="playerimg">
		</div>
		<div id="mice">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action2'">쫓아내기</button>
			<img src="img/mice.png" id="miceimg">
		</div>
		<%
		break;
		case "action2":
			if (Charac.player.getStory() < 2) {
				Log.turnCount++;
				Charac.player.setPower(Charac.player.getPower() - 1);
				log.send("[ " + Log.turnCount + " ] 쥐가 도망갔습니다. (힘 -1)", "normal");
				Charac.player.setStory(2);
				Charac.player.setExp(Charac.player.getExp() + 20);
				log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +20)", "story");
				log.send("💡 침대에서 자면 힘을 회복할 수 있습니다.", "tip");
			}
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action3" name="mode" />
			<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
		</jsp:forward>
		<%
		case "action3":
		%>
		<div id="player">
			<img src="img/humanactive.jpg" id="playerimg">
		</div>
		<%
		break;

		}
		%>
	</div>
	<!---------------------------------------------------------------------------------------------------------------------------->
	<div id="e">
		<%
		if (Charac.player.getStory() >= map_i.getOpenStory(Map.currentMap.getMapEast())) {
		%>
		<button id="we_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.currentMap.getMapEast()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapEast())%></button>
		<%
		}
		%>
	</div>
	<div id="s">
		<button id="ns_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.currentMap.getMapSouth()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapSouth())%></button>
	</div>
</body>
</html>