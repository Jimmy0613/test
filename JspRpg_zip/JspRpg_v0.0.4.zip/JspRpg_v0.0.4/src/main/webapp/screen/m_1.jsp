<%@page import="com.cre.w.rpg.sys.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>나의 방</title>
<link rel="stylesheet" href="../css/m_1.css">
</head>
<body>
	<%
	Map map_i = new Map();
	Charac character = new Charac();
	Log log = new Log();
	map_i.load(request.getParameter("m_id"));
	String mode = request.getParameter("mode");
	%>

	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n">
		<%
		if (Charac.player.getStory() >= map_i.getOpenStory(Map.currentMap.getMapNorth())) {
		%>
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapNorth()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapNorth())%></button>
		<%
		}
		%>
	</div>
	<div id="w"></div>
	<!---------------------------------------------------스크린 --------------------------------------------------->
	<div id="screen_c">
		<%
		String msg = "";
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action1'">잠자기</button>
			<img src="img/bed.jpg" id="bedimg">
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			if (Charac.player.getPower() == Charac.player.getMaxPower()) {
				log.send(Charac.player.getName() + "🗣 \"지금은 잘 필요가 없는 것 같은데?\"", "speech");
				if (Charac.player.getStory() < 0) {
			Charac.player.setStory(0);
			Charac.player.setExp(Charac.player.getExp() + 5);
			log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +5)", "story");
			log.send("💡 ''지난 이야기 보기''를 통해 완료한 이야기 목록을 볼 수 있습니다.", "tip");
			log.send("🏃‍♂️ 새로운 지역이 열렸습니다. (복도)", "map");
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="normal" name="mode" />
			<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
		</jsp:forward>
		<%
		}
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action1'">잠자기</button>
			<img src="img/bed.jpg" id="bedimg">
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		} else {
		Log.turnCount++;
		log.send("[ " + Log.turnCount + " ] 🛏 침대에 누웠습니다..", "normal");
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action2'">일어나기</button>
			<img src="img/sleeping.jpg" id="bedimg">
		</div>
		<%
		}
		break;
		case "action2":
		Log.turnCount++;
		Charac.player.setPower(Charac.player.getMaxPower());
		log.send("[ " + Log.turnCount + " ] 힘을 회복했습니다.", "normal");
		if (Charac.player.getStory() < 3) {
		Charac.player.setStory(3);
		Charac.player.setExp(Charac.player.getExp() + 10);
		log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +10)", "story");
		log.send("🏃‍♂️ 새로운 지역이 열렸습니다. (주방)", "map");
		}
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action3" name="mode" />
			<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
		</jsp:forward>
		<%
		case "action3":
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action1'">잠자기</button>
			<img src="img/bed.jpg" id="bedimg">
		</div>
		<div id="player">
			<img src="img/humanPower.png" id="playerimg">
		</div>
		<%
		break;

		}
		%>
	</div>
	<!----------------------------------------------------------------------------------------------------------------->
	<div id="e"></div>
	<div id="s"></div>
</body>
</html>