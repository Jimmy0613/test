<%@page import="com.cre.w.rpg.sys.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>주방</title>
<link rel="stylesheet" href="../css/m_3.css">

</head>
<body>
	<%
	Map map_i = new Map();
	Log log = new Log();

	map_i.load(request.getParameter("m_id"));
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w"></div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
		%>
		<div id="fridge">
			<img src="img/fridge.jpg" id="fridgeimg">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action1'">열기</button>
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			if (Charac.player.getStory() < 4) {
				Charac.player.setStory(4);
				Charac.player.setExp(Charac.player.getExp() + 5);
				Log.turnCount++;
				log.send("[ " + Log.turnCount + " ] 냉장고를 열었습니다.", "normal");
				log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +5)", "story");
				log.send("🎉 새로운 지역이 열렸습니다. (다용도실)", "map");
				log.send("💡 냉장고에는 음식 아이템을 넣을 수 있습니다.", "tip");
			}
		%>
		<button id="f_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=normal'">닫기</button>
		<div id="f_open">
			<div id="content_t">냉장고</div>
			<div id="content_t">가방(음식)</div>
			<div id="f_inside">
				<div id="item">1</div>
				<div id="item">2</div>
				<div id="item">3</div>
				<div id="item">4</div>
				<div id="item">5</div>
				<div id="item">6</div>
				<div id="item">1</div>
				<div id="item">2</div>
				<div id="item">3</div>
				<div id="item">4</div>
				<div id="item">5</div>
				<div id="item">6</div>
			</div>
			<div id="f_b_food">
				<%@include file="bag_food.jsp"%>
			</div>
		</div>
		<%
		break;

		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e">
		<button id="we_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.currentMap.getMapEast()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapEast())%></button>
	</div>
	<div id="s">
		<%
		if (Charac.player.getStory() >= map_i.getOpenStory(Map.currentMap.getMapSouth())) {
		%>
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapSouth()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapSouth())%></button>
		<%
		}
		%>
	</div>
</body>
</html>