<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@page import="com.cre.w.rpg.sys.Map"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>마당</title>
<link rel="stylesheet" href="../css/m_6.css">

</head>
<body>
	<%
	Map map_i = new Map();
	Charac character = new Charac();
	Log log = new Log();
	map_i.load(request.getParameter("m_id"));
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n">
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapNorth()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapNorth())%></button>
	</div>
	<div id="w"></div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
			if (Charac.player.getStory() < 8) {
				log.send(Charac.player.getName() + "🗣 \"돈이다! \"", "speech");
		%>
		<div id="sp1">
			<img src="img/sp_m6_1.jpg">
		</div>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player">
			<img src="img/human6.jpg">
		</div>
		<div id="coin">
			<img src="img/coin.jpg">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action1'">줍기</button>
		</div>

		<%
		} else if (Charac.player.getStory() == 8) {
		log.send(Charac.player.getName() + "🗣 \"깜짝이야! 누구세요?! \"", "speech");
		%>
		<div id="sp3">
			<img src="img/sp_m6_3.jpg">
		</div>
		<div id="wall2">
			<img src="img/wallhuman.png">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action2'">다가가기</button>
		</div>
		<div id="player">
			<img src="img/human6.jpg">
		</div>

		<%
		} else {
		%>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player">
			<img src="img/humannormal.jpg">
		</div>
		<%
		}
		break;
		case "action1":
		Charac.player.setStory(8);
		Charac.player.setExp(Charac.player.getExp() + 5);
		Charac.player.setCoin(Charac.player.getCoin() + 5);
		log.send(Charac.player.getName() + "🗣 \"아싸! \"", "speech");
		log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +5, 금화 +5)", "story");
		%>
		<div id="sp2">
			<img src="img/sp_m6_2.jpg">
		</div>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player2">
			<img src="img/humancoin.png">
		</div>
		<%
		break;
		case "action2":
			Charac.player.setStory(9);
			log.send(Charac.player.getName() + "🗣 \"사라졌다?! \"", "speech");
			log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +10)", "story");
			log.send("🏃‍♂️ 새로운 지역이 열렸습니다. (집 앞)", "map");
		%>

		<div id="sp4">
			<img src="img/sp_m6_4.jpg">
		</div>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player">
			<img src="img/humansurprised.jpg">
		</div>
		<%
		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e">
		<%
		if (Charac.player.getStory() >= map_i.getOpenStory(Map.currentMap.getMapEast())) {
		%>
		<button id="we_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapEast()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapEast())%></button>
		<%
		}
		%>
	</div>
	<div id="s"></div>
</body>
</html>