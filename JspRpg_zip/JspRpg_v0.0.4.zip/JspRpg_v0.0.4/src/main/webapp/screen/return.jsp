<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Map"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	Charac character = new Charac();
	Log log = new Log();
	if (Charac.player.getPower() <= 0) {
		Charac.player.setPower(0);
		character.reload();
		log.send("힘이 모두 빠져 ''나의 방''으로 소환되었습니다..", "bad");
	%>
	<jsp:forward page="game.jsp">
		<jsp:param value="normal" name="mode" />
		<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
	</jsp:forward>

	<%
	} else if (Charac.player.getStory() < 6) {
			log.send("❌ ''이야기 <6> 지도''를 먼저 완료해야 합니다.", "bad");
	%>
	<jsp:forward page="game.jsp">
		<jsp:param value="normal" name="mode" />
		<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
	</jsp:forward>
	<%
	} else {
	%>
	<jsp:forward page="game.jsp">
		<jsp:param value="move" name="mode" />
		<jsp:param value="m_1" name="m_id" />
	</jsp:forward>
	<%
	}
	%>
</body>
</html>