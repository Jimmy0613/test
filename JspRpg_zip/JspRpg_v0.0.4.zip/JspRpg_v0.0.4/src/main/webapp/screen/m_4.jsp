<%@page import="com.cre.w.rpg.sys.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>다용도실</title>
<link rel="stylesheet" href="../css/m_4.css">

</head>
<body>
	<%
	Map map_i = new Map();
	Charac ch = new Charac();
	Log log = new Log();
	map_i.load(request.getParameter("m_id"));
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n">
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapNorth()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapNorth())%></button>
	</div>
	<div id="w"></div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
			if (Charac.player.getStory() < 5) {
		%>
		<div id="bag">
			<img src="img/bag.png" id="bagimg">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action1'">살펴보기</button>
		</div>
		<%
		}
		%>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			Charac.player.setStory(5);
			Charac.player.setExp(Charac.player.getExp() + 5);
			log.send(Charac.player.getName() + "🗣 \"가방이다! \"","speech");
			log.send("👜 이제 가방을 사용할 수 있습니다.","good");
			log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +5)","story");
			log.send("🏃‍♂️ 새로운 지역이 열렸습니다. (거실)","map");
		%>
		<div id="player">
			<img src="img/humanbag.png" id="playerimg2">
		</div>
		<%
		break;

		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e"></div>
	<div id="s"></div>
</body>
</html>