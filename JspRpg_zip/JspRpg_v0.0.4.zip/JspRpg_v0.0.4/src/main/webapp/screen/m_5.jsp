<%@page import="com.cre.w.rpg.sys.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>거실</title>
<link rel="stylesheet" href="../css/m_5.css">

</head>
<body>
	<%
	Map map_i = new Map();
	Charac character = new Charac();
	Log log = new Log();
	map_i.load(request.getParameter("m_id"));
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w">
		<button id="we_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapWest()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapWest())%></button>
	</div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
		%>
		<div id="desk">
			<img src="img/desk.png" id="deskimg">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapId()%>&mode=action1'">서랍
				열기</button>
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			if (Charac.player.getStory() < 6) {
				Charac.player.setStory(6);
				Charac.player.setExp(Charac.player.getExp() + 5);
				Log.turnCount++;
				log.send("[ " + Log.turnCount + " ] 서랍을 열었습니다.", "normal");
				log.send(Charac.player.getName() + "🗣 \"지도다! \"", "speech");
				log.send("👜 이제 지도를 사용할 수 있습니다.", "good");
				log.send("🎉 새로운 이야기를 완료했습니다. (경험치 +5)", "story");
				log.send("💡 ''방으로'' 아이콘을 누르면 즉시 \'나의 방\'으로 이동할 수 있습니다.", "tip");
		%>
		<div id="desk">
			<img src="img/desk.png" id="deskimg">
		</div>
		<div id="player">
			<img src="img/humanmap.png" id="playerimg2">
		</div>
		<%
		} else {
		Log.turnCount++;
		log.send("[ " + Log.turnCount + " ] 서랍을 열었습니다. 아무것도 없습니다.", "normal");
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="normal" name="mode" />
			<jsp:param value="<%=Map.currentMap.getMapId()%>" name="m_id" />
		</jsp:forward>
		<%
		}
		break;

		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e"></div>
	<div id="s">
		<%
		if (Charac.player.getStory() >= map_i.getOpenStory(Map.currentMap.getMapSouth())) {
		%>
		<button id="ns_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.currentMap.getMapSouth()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapSouth())%></button>
		<%
		}
		%>
	</div>
</body>
</html>