<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@page import="com.cre.w.rpg.sys.Map"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>집 앞</title>
<link rel="stylesheet" href="../css/m_6.css">

</head>
<body>
	<%
	Map map_i = new Map();
	Charac c = new Charac();
	Log l = new Log();
	map_i.load(request.getParameter("m_id"));
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w">
		<button id="we_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.currentMap.getMapWest()%>&mode=move'"><%=map_i.getName(Map.currentMap.getMapWest())%></button>
	</div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
			out.println("준비중 ㅎㅎ");
		break;
		case "action1":
	
		break;
		case "action2":
		
		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e"></div>
	<div id="s"></div>
</body>
</html>