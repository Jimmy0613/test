<%@page import="com.cre.w.rpg.sys.Map"%>
<%@page import="com.cre.w.rpg.sys.Log"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	Charac character = new Charac();
		Map map = new Map();
		Log log = new Log();

		String c_name = request.getParameter("c_name");
		character.load(c_name);
		
		map.load(Charac.player.getLocation());
		log.load();
		log.send("[ " + Log.turnCount + " ] 환영합니다!", "good");
		log.send("💡 시스템 메시지는 캐릭터 변경, 로그아웃시 초기화됩니다.", "tip");
		response.sendRedirect("game.jsp?m_id=" + Map.currentMap.getMapId() + "&mode=normal");
	%>
</body>
</html>