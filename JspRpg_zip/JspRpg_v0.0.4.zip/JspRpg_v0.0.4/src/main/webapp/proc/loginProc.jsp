<%@page import="com.cre.w.rpg.sys.Member"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

</head>
<body>
	<%
	Member member = new Member();
	String input_id = request.getParameter("id");
	String input_pw = request.getParameter("pw");
	
	String alert = member.loginAlert(input_id, input_pw);

	if (alert.equals("")) {
		member.login(input_id);
		session.setAttribute("loginId", Member.loginMember.getId());
		session.setAttribute("loginName", Member.loginMember.getName());
		session.setAttribute("loginC1", Member.loginMember.getCh1());
		session.setAttribute("loginC2", Member.loginMember.getCh2());
		session.setAttribute("loginInfo", member.loginInfo());
		
		out.println("<script>location.href='../character.jsp'</script>");
	} else {
		out.println("<script>alert('로그인 실패 " + alert + "')</script>");
		out.println("<script>location.href='../login.jsp'</script>");
	}
	%>
</body>
</html>