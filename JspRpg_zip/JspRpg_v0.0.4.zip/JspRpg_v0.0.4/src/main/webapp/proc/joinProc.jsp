<%@page import="com.cre.w.rpg.sys.Member"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	Member member = new Member();
	String input_id = request.getParameter("id");
	String input_pw1 = request.getParameter("pw1");
	String input_pw2 = request.getParameter("pw2");
	String input_name = request.getParameter("m_name");
	String input_email1 = request.getParameter("email1");
	String input_email2 = request.getParameter("email2");
	
	String alert = member.joinAlert(input_id, input_pw1, input_pw2, input_name);
	if (alert.equals("")) {
		String email = "";
		if (input_email1.equals("") || input_email2.equals("")) {
			email = "미등록";
		} else {
			email = input_email1 + "@" + input_email2;
		}
		member.newMember(input_id, input_pw1, input_name, email);
		out.println("<script>alert('가입 완료! 로그인 화면으로 이동합니다.');</script>");
		out.println("<script>location.href='../login.jsp'</script>");
	} else {
		out.println("<script>alert('가입에 실패하였습니다.. " + alert + "');</script>");
		out.println("<script>location.href='../join.jsp'</script>");
	}
	%>

</body>
</html>