<%@page import="com.cre.w.rpg.sys.Member"%>
<%@page import="com.cre.w.rpg.sys.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

</head>
<body>
	<%
	Member member = new Member();
	Charac character = new Charac();
	String loginId = (String) session.getAttribute("loginId");
	String loginC1 = (String) session.getAttribute("loginC1");
	String loginC2 = (String) session.getAttribute("loginC2");
	String input_name = request.getParameter("c_name");
	String alert = character.newAlert(input_name);

	if (alert.equals("")) {
		character.newCharacter(input_name, loginId);
		if (loginC1.equals("x")) {
			member.updateCharacter("CHARACTER1", input_name, loginId);
			session.setAttribute("loginC1", input_name);
		} else {
			member.updateCharacter("CHARACTER2", input_name, loginId);
			session.setAttribute("loginC2", input_name);
		}
		out.println("<script>location.href='../character.jsp'</script>");
	} else {
		out.println("<script>alert('사용할 수 없는 이름입니다. " + alert + "')</script>");
		out.println("<script>location.href='../newChar.jsp'</script>");
	}
	%>
</body>
</html>