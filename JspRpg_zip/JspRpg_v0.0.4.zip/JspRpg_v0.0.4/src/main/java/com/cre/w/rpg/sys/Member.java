package com.cre.w.rpg.sys;

import java.util.ArrayList;

import com.cre.w.rpg.dao.MemberDAO;
import com.cre.w.rpg.db.Db;
import com.cre.w.rpg.dto.MemberDTO;

public class Member extends MemberDAO {

	public static MemberDTO loginMember = null;

	public void newMember(String id, String pw, String name, String email) {
		String sql = String.format(
				"INSERT INTO %s(MEMBER_ID, PASSWORD, MEMBER_NAME, EMAIL) VALUES('%s','%s','%s','%s');", Db.TABLE_MEMBER,
				id, pw, name, email);
		update(sql);
	}

	public void updateCharacter(String char12, String c_name, String loginId) {
		String sql = String.format("UPDATE %s SET %s = '%s' WHERE MEMBER_ID = '%s';", Db.TABLE_MEMBER, char12, c_name,
				loginId);
		update(sql);
	}

	public boolean isId(String id) { // id가 존재하면 true, 아니면 false를 리턴하는 함수
		ArrayList<MemberDTO> dtos = select();
		boolean is = false;
		for (MemberDTO m : dtos) {
			if (m.getId().equals(id)) {
				return is = true;
			}
		}
		return is;
	}

	public boolean isName(String name) { // 이름 존재하면 true, 아니면 false를 리턴하는 함수
		ArrayList<MemberDTO> dtos = select();
		boolean is = false;
		for (MemberDTO m : dtos) {
			if (m.getName().equals(name)) {
				return is = true;
			}
		}
		return is;
	}

	public boolean pwCheck(String id, String pw) {
		ArrayList<MemberDTO> dtos = select();
		boolean correct = false;
		for (MemberDTO m : dtos) {
			if (m.getId().equals(id)) {
				if (m.getPw().equals(pw)) {
					return correct = true;
				}
			}
		}
		return correct;
	}

	public String joinAlert(String input_id, String input_pw1, String input_pw2, String input_name) {
		String alert = "";
		if (input_id.length() > 12) {
			alert = alert + "(아이디 글자 수 확인)";
		} else if (isId(input_id)) {
			alert = alert + "(중복된 아이디) ";
		}
		if (input_pw1.length() > 14) {
			alert = alert + "(비밀번호 글자 수 확인) ";
		} else if (!input_pw1.equals(input_pw2)) {
			alert = alert + "(비밀번호 일치하지 않음) ";
		}
		if (input_name.length() > 6) {
			alert = alert + "(이름 글자 수 확인) ";
		} else if (isName(input_name)) {
			alert = alert + "(중복된 이름) ";
		}

		return alert;
	}

	public String loginAlert(String input_id, String input_pw) {
		String alert = "";
		if (!isId(input_id)) {
			alert = alert + "(존재하지 않는 아이디) ";
		} else if (!pwCheck(input_id, input_pw)) {
			alert = alert + "(비밀번호 불일치)";
		}
		return alert;
	}

	public void login(String member_id) {
		ArrayList<MemberDTO> dtos = select();
		for (MemberDTO m : dtos) {
			if (m.getId().equals(member_id)) {
				loginMember = m;
			}
		}
	}
	
	public String loginInfo() {
		String info = "🙂 먼저 로그인해주세요. 🙂";
		if(loginMember==null) {
			return info;
		} else {
			return info = "🙂 " + loginMember.getName() + "님 (" + loginMember.getId() + ") 🙂";
		}
	}
}
