package com.cre.w.rpg.sys;

import java.util.ArrayList;

import com.cre.w.rpg.dao.StoryDAO;
import com.cre.w.rpg.dto.StoryDTO;

public class Story extends StoryDAO{
	
	public ArrayList<StoryDTO> load() {
		ArrayList<StoryDTO> dtos = select();
		ArrayList<StoryDTO> story = new ArrayList<>();
		for(StoryDTO s : dtos) {
			if(s.getStNum()<=Charac.player.getStory()) {
				story.add(s);
			}
		}
		
		return story;
	}
}
