package com.cre.w.rpg.dao;

import java.util.ArrayList;

import com.cre.w.rpg.db.Db;
import com.cre.w.rpg.dto.MapDTO;
import com.cre.w.rpg.sys.Charac;

public class MapDAO extends DAO {

	LogDAO log = new LogDAO();
	Charac ch = new Charac();
	
	public ArrayList<MapDTO> select() {
		connection();
		ArrayList<MapDTO> dtos = new ArrayList<>();
		String sql = String.format("SELECT * FROM %s;", Db.TABLE_MAP);
		try {
			result = st.executeQuery(sql);
			while (result.next()) {
				String map_id = result.getString("MAP_ID");
				String m_name = result.getString("M_NAME");
				String m_desc = result.getString("M_DESC");
				int open_story = result.getInt("OPEN_STORY");
				String m_east = result.getString("M_E");
				String m_west = result.getString("M_W");
				String m_south = result.getString("M_S");
				String m_north = result.getString("M_N");

				MapDTO dto = new MapDTO(map_id, m_name, m_desc, open_story, m_east, m_west, m_south, m_north);
				dtos.add(dto);
			}
		} catch (Exception e) {

		} finally {
			try {
				if (result != null)
					result.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}

		return dtos;

	}

}
