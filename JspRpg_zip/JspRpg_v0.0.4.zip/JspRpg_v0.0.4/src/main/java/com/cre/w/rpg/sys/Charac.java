package com.cre.w.rpg.sys;

import java.util.ArrayList;

import com.cre.w.rpg.dao.CharacterDAO;
import com.cre.w.rpg.db.Db;
import com.cre.w.rpg.dto.CharacterDTO;

public class Charac extends CharacterDAO {

	Log log = new Log();

	public static CharacterDTO player = null;
	public static String playerInfo = "";

	public boolean isName(String name) { // 이름 존재하면 true, 아니면 false를 리턴하는 함수
		ArrayList<CharacterDTO> dtos = select();
		boolean is = false;
		for (CharacterDTO c : dtos) {
			if (c.getName().equals(name)) {
				return is = true;
			}
		}
		return is;
	}
	public String newAlert(String input_name) {
		String alert = "";
		if (isName(input_name)) {
			alert = alert + "(이미 사용 중)";
		} else if (input_name.length() < 2 || input_name.length() > 6) {
			alert = alert + "(글자 수 확인)";
		}
		return alert;
	}
	
	public void newCharacter(String name, String mem_id) {
		String sql = String.format("INSERT INTO %s(NAME, MEMBER_ID) VALUES('%s','%s');", Db.TABLE_CHARACTER, name,
				mem_id);
		update(sql);
	}

	public void update(String column, String value) {
		String sql = String.format("UPDATE %s SET %s = '%s' WHERE NAME = '%s'", Db.TABLE_CHARACTER, column, value,
				Charac.player.getName());
		update(sql);
	}

	public void update(String column, int value) {
		String sql = String.format("UPDATE %s SET %s = %d WHERE NAME = '%s'", Db.TABLE_CHARACTER, column, value,
				Charac.player.getName());
		update(sql);
	}

	public void load(String currentCharacter) {
		ArrayList<CharacterDTO> dtos = select();
		for (CharacterDTO c : dtos) {
			if (c.getName().equals(currentCharacter)) {
				player = c;
				playerInfo = "👤 " + currentCharacter + " 👤 ✨레벨( " + c.getLevel() + " ) 💪힘( " + c.getPower() + " / "
						+ c.getMaxPower() + " ) 💰금화 ( " + c.getCoin() + " 개)";
			}
		}
	}



	public void levelCheck() {
		if (player.getExp() >= player.getMaxExp()) {
			int exp_over = player.getExp() - player.getMaxExp();
			player.setLevel(player.getLevel() + 1);
			player.setMaxPower(player.getMaxPower() + 1);
			player.setPower(player.getMaxPower());
			player.setMaxExp(player.getMaxExp() * 13 / 10);
			player.setExp(exp_over);
			log.send("🎊 레벨이 올랐습니다. (레벨 " + player.getLevel() + ", 최대 힘 +1)", "good");
		}
	}

	public void reload() {
		levelCheck();
		update("power", player.getPower());
		update("Level", player.getLevel());
		update("max_power", player.getMaxPower());
		update("coin", player.getCoin());
		update("exp", player.getExp());
		update("max_exp", player.getMaxExp());
		update("story", player.getStory());
		update("location", player.getLocation());

		load(player.getName());
	}

	public String profile(String c_name) {
		String charInfo = "";
		String icon = "";
		int level = 0;
		ArrayList<CharacterDTO> dtos = select();
		for (CharacterDTO c : dtos) {
			if (c.getName().equals(c_name)) {
				level = c.getLevel();
			}
		}
		if (level < 5) {
			icon = "🐣";
		} else if (level < 10) {
			icon = "🐥";
		} else {
			icon = "🦅";
		}
		charInfo += icon + " " + c_name + " ( 레벨: " + level + " )";
		return charInfo;
	}
}
