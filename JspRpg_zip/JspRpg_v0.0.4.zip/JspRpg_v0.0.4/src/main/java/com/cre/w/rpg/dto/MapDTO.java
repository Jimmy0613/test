package com.cre.w.rpg.dto;

public class MapDTO {
	String mapId;
	String name;
	String desc;
	int openStory;
	String mapEast;
	String mapWest;
	String mapSouth;
	String mapNorth;
	
	public MapDTO(String map_id, String name, String desc, int open_story, String map_east, String map_west,
			String map_south, String map_north) {
		super();
		this.mapId = map_id;
		this.name = name;
		this.desc = desc;
		this.openStory = open_story;
		this.mapEast = map_east;
		this.mapWest = map_west;
		this.mapSouth = map_south;
		this.mapNorth = map_north;
	}

	public String getMapId() {
		return mapId;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

	public int getOpenStory() {
		return openStory;
	}

	public String getMapEast() {
		return mapEast;
	}

	public String getMapWest() {
		return mapWest;
	}

	public String getMapSouth() {
		return mapSouth;
	}

	public String getMapNorth() {
		return mapNorth;
	}
}
