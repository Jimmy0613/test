package com.cre.w.rpg.dao;

import java.util.ArrayList;

import com.cre.w.rpg.db.Db;
import com.cre.w.rpg.dto.LogDTO;

public class LogDAO extends DAO {
	
	public ArrayList<LogDTO> select() {
		connection();
		ArrayList<LogDTO> dtos = new ArrayList<>();

		String sql = String.format("SELECT * FROM %s", Db.TABLE_LOG);

		try {
			result = st.executeQuery(sql);
			while (result.next()) {
				int log_num = result.getInt("LOG_NUM");
				String log = result.getString("LOG");
				String cls = result.getString("CLASS");

				LogDTO dto = new LogDTO(log_num, log, cls);

				dtos.add(dto);
			}
		} catch (Exception e) {
		} finally {
			try {
				if (result != null)
					result.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}

		return dtos;
	}
	
	public void update(String sql) {
		connection();
		try {
			st.executeUpdate(sql);
		} catch (Exception e) {
		} finally {
			try {
				if (result != null)
					result.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
	}
}
