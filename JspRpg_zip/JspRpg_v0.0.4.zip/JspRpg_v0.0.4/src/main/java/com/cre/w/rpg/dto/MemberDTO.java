package com.cre.w.rpg.dto;

public class MemberDTO {
	private String id;
	private String pw;
	private String name;
	private String ch1;
	private String ch2;

	public MemberDTO(String id, String pw, String name, String ch1, String ch2) {
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.ch1 = ch1;
		this.ch2 = ch2;
	}

	public String getId() {
		return id;
	}

	public String getPw() {
		return pw;
	}

	public String getName() {
		return name;
	}

	public String getCh1() {
		return ch1;
	}

	public String getCh2() {
		return ch2;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCh1(String ch1) {
		this.ch1 = ch1;
	}

	public void setCh2(String ch2) {
		this.ch2 = ch2;
	}
}
