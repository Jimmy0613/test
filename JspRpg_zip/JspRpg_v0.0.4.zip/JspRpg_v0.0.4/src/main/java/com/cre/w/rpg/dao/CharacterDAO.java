package com.cre.w.rpg.dao;

import java.util.ArrayList;

import com.cre.w.rpg.db.Db;
import com.cre.w.rpg.dto.CharacterDTO;

public class CharacterDAO extends DAO {
	
	public ArrayList<CharacterDTO> select() {
		connection();
		ArrayList<CharacterDTO> dtos = new ArrayList<>();
		String sql = String.format("SELECT * FROM %s;", Db.TABLE_CHARACTER);
		try {
			result = st.executeQuery(sql);
			while (result.next()) {
				String mem_id = result.getString("MEMBER_ID");
				String name = result.getString("NAME");
				String location = result.getString("LOCATION");
				int story = result.getInt("STORY");
				int level = result.getInt("LEVEL");
				int exp = result.getInt("EXP");
				int max_exp = result.getInt("MAX_EXP");
				int power = result.getInt("POWER");
				int max_power = result.getInt("MAX_POWER");
				int coin = result.getInt("COIN");

				CharacterDTO dto = new CharacterDTO(mem_id, name, location, story, level, exp, max_exp, power,
						max_power, coin);
				dtos.add(dto);
			}
		} catch (Exception e) {

		} finally {
			try {
				if (result != null)
					result.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return dtos;
	}
	
	public void update(String sql) {
		connection();
		try {
			st.executeUpdate(sql);
		} catch (Exception e) {
		} finally {
			try {
				if (result != null)
					result.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
	}

	

}
