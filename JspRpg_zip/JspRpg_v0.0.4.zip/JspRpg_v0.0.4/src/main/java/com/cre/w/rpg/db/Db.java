package com.cre.w.rpg.db;

public class Db {
	//테이블&디비 이름============================================
	public static final String DATABASE = "RPG";
	public static final String TABLE_MEMBER = "MEMBERS";
	public static final String TABLE_CHARACTER = "CHARACTERS";
	public static final String TABLE_MAP = "MAP";
	public static final String TABLE_LOG = "LOG";
	public static final String TABLE_STORY = "STORY";
	
}
