package com.cre.w.rpg.sys;

import java.util.ArrayList;

import com.cre.w.rpg.dao.MapDAO;
import com.cre.w.rpg.dto.MapDTO;

public class Map extends MapDAO{
	Charac ch = new Charac();
	Log log = new Log();

	public static MapDTO currentMap = null;
	public static String currentMapInfo = null;
	
	public void load(String map_id) {
		ArrayList<MapDTO> dtos = select();
		for (MapDTO dto : dtos) {
			if (dto.getMapId().equals(map_id)) {
				currentMap = dto;
				currentMapInfo = "[ " + currentMap.getName() + " ] " + currentMap.getDesc();
			}
		}
	}
	
	public String getName(String map_id) {
		ArrayList<MapDTO> dtos = select();
		String mapName = null;
		for (MapDTO dto : dtos) {
			if (dto.getMapId().equals(map_id)) {
				mapName = dto.getName();
			}
		}
		return mapName;
	}
	
	public int getOpenStory(String map_id) {
		ArrayList<MapDTO> dtos = select();
		int openStory = 0;
		for (MapDTO dto : dtos) {
			if (dto.getMapId().equals(map_id)) {
				openStory = dto.getOpenStory();
			}
		}
		return openStory;
	}

	public void move() {
		Log.turnCount++;
		log.send("[ " + Log.turnCount + " ] " + currentMap.getName() + "(으)로 이동했습니다.", "normal");
		Charac.player.setLocation(currentMap.getMapId());
		ch.reload();
	}

}
