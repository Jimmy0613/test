package com.cre.w.rpg.dao;

import java.util.ArrayList;

import com.cre.w.rpg.db.Db;
import com.cre.w.rpg.dto.MemberDTO;

public class MemberDAO extends DAO {

	public ArrayList<MemberDTO> select() {
		connection();
		ArrayList<MemberDTO> dtos = new ArrayList<>();
		String sql = String.format("SELECT * FROM %s;", Db.TABLE_MEMBER);
		try {
			result = st.executeQuery(sql);
			while (result.next()) {
				String id = result.getString("MEMBER_ID");
				String pw = result.getString("PASSWORD");
				String name = result.getString("MEMBER_NAME");
				String ch1 = result.getString("CHARACTER1");
				String ch2 = result.getString("CHARACTER2");

				MemberDTO dto = new MemberDTO(id, pw, name, ch1, ch2);
				dtos.add(dto);
			}
		} catch (Exception e) {

		} finally {
			try {
				if (result != null)
					result.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}

		return dtos;

	}
	
	public void update(String sql) {
		connection();
		try {
			st.executeUpdate(sql);
		} catch (Exception e) {
		} finally {
			try {
				if (result != null)
					result.close();
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
	}
}
