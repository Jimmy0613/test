package com.cre.w.rpg.game;

import com.cre.w.rpg.db.DataSelect;
import com.cre.w.rpg.db.DataUpdate;

public class Map {
	//현재 맵 기준 정보들================
	public static String m_id = "";
	public static String m_name = "";
	public static String m_desc = "";
	public static String m_e = "x";
	public static String m_w = "x";
	public static String m_s = "x";
	public static String m_n = "x";
	//==============================
	DataUpdate du = new DataUpdate();
	DataSelect ds = new DataSelect();
	Log l = new Log();
	
	public void loadMap() {
		String where = "where m_id = '" + m_id +"'";
		m_name = ds.dbExecuteQueryStr("m_name", "map", where);
		m_desc = ds.dbExecuteQueryStr("m_desc", "map", where);
		m_e = ds.dbExecuteQueryStr("m_e", "map", where);
		m_w = ds.dbExecuteQueryStr("m_w", "map", where);
		m_s = ds.dbExecuteQueryStr("m_s", "map", where);
		m_n = ds.dbExecuteQueryStr("m_n", "map", where);
	}

	public String getInfo() {
		String where = "where m_id = '" + m_id +"'";
		String name = ds.dbExecuteQueryStr("m_name", "map", where);
		String desc = ds.dbExecuteQueryStr("m_desc", "map", where);
		String info = "[ " + name + " ] " + desc;
		return info;
	}
	
	public String getName(String m_id) {
		String where = "where m_id = '" + m_id +"'";
		String name = ds.dbExecuteQueryStr("m_name", "map", where);
		String info = name;
		return info;
	}
	
	public void move() {
		Charac ch = new Charac();
		l.turn();
		du.sendSystemMsg("[ " + Log.turnCount + " ] " + m_name + "(으)로 이동했습니다.","normal");
		Charac.location = Map.m_id;
		ch.updateCharacter();
	}
	
}
