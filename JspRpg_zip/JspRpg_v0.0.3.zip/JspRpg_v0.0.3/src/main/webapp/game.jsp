<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<%
/* CSS/JS 파일 캐시 방지 */
String styleCss = application.getRealPath("/css/common.css");
File style = new File(styleCss);
Date lastModifiedStyle = new Date(style.lastModified());
SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddhhmmssSSS");
%>
<link rel="stylesheet"
	href="css/common.css?ver=<%=fmt.format(lastModifiedStyle)%>">
<link rel="stylesheet"
	href="css/screen.css?ver=<%=fmt.format(lastModifiedStyle)%>">
<link rel="stylesheet"
	href="css/system.css?ver=<%=fmt.format(lastModifiedStyle)%>">
<link rel="stylesheet"
	href="css/sys_game.css?ver=<%=fmt.format(lastModifiedStyle)%>">
<link rel="stylesheet"
	href="css/map.css?ver=<%=fmt.format(lastModifiedStyle)%>">
</head>
<body>

	<%
	Map map = new Map();
	map.loadMap();
	Map.m_id = request.getParameter("m_id");
	String map_jsp = "screen/" + Map.m_id + ".jsp";
	String mode = request.getParameter("mode");
	%>
	<div id="gamebox">
		<div id="screen">
			<%
			if (mode.equals("bag")) {
			%>
			<%@ include file="screen/bag.jsp"%>
			<%
			} else if (mode.equals("map")) {
			%>
			<%@ include file="screen/map.jsp"%>
			<%
			} else if (mode.equals("return")) {
			%>
			<%@ include file="screen/return.jsp"%>
			<%
			} else {
			%>
			<jsp:include page="<%=map_jsp%>">
				<jsp:param value="<%=mode%>" name="mode" />
				<jsp:param value="<%=Map.m_id%>" name="m_id" />
			</jsp:include>
			<%
			}
			%>
		</div>
		<div id="system">
			<%@ include file="system/sys_game.jsp"%>
		</div>
	</div>
</body>
</html>