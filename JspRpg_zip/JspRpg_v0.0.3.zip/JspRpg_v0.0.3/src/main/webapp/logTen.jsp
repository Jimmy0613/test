<%@page import="com.cre.w.rpg.db.DataSelect"%>
<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	DataSelect ds = new DataSelect();
	String where = "order by sm_num desc limit 0, 9";
	ArrayList<String> msgs = ds.dbExecuteQueryStrArr("msg", "log", where);
	ArrayList<String> msgclass = ds.dbExecuteQueryStrArr("class", "log", where);
	String str = "";
	String cl = "";
	if (msgs.size() != 0) {
		for (int i = msgs.size() - 1; i >= 0; i--) {
			str = msgs.get(i);
			cl = msgclass.get(i);
			switch (cl) {
			case "normal":
	%>
	<span><%=str%></span>
	<%
	break;
	case "story":
	%>
	<span style="color: skyblue"><%=str%></span>
	<%
	break;
	case "map":
	%>
	<span style="color: orange"><%=str%></span>
	<%
	break;
	case "good":
	%>
	<span style="color: lightgreen"><%=str%></span>
	<%
	break;
	case "tip":
	%>
	<span style="color: yellow"><%=str%></span>
	<%
	break;
	case "bad":
	%>
	<span style="color: brown"><%=str%></span>
	<%
	break;
	case "speech":
	%>
	<span style="color: pink"><%=str%></span>
	<%
	break;
	}
	%>
	<br>
	<%
	}
	}
	%>
</body>
</html>