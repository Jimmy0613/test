<%@page import="com.cre.w.rpg.db.Member"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@page import="com.cre.w.rpg.game.Map"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	Map map_i = new Map();
	Charac ch = new Charac();
	Member mem = new Member();
	%>
	<script>
		function showLog() {
			window.open("log.jsp", "지난 로그",
					"width=500, height=700, top=200, left=100");
		}
		function showStory() {
			window.open("story.jsp", "지난 이야기",
					"width=500, height=300, top=200, left=100");
		}
	</script>

	<div id="s_info">
		<%
		ch.updateCharacter();
		ch.loadCharacter();
		%>
		<div><%=Charac.info%></div>
	</div>
	<div id="s_menu_right_t">메뉴</div>
	<div id="s_content">
		<div id="exp">
			경험치 [
			<%=Charac.exp%>
			/
			<%=Charac.max_exp%>
			]
		</div>

		<div id="map_info">
			<%
			map_i.loadMap();
			%>
			현재 위치:
			<%=map_i.getInfo()%>
		</div>
		<div id="msgbox">
			<%@include file="../logTen.jsp"%>
		</div>
		<div id="show">
			<button onclick="showLog();">지난 기록 보기</button>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button onclick="showStory();">지난 이야기 보기</button>
		</div>
	</div>
	<div id="s_menu_right">
		<div class="icon" id="icon1">
			<a href="../game.jsp?m_id=<%=Map.m_id%>&mode=return"><img
				src="../img/returnhome.png"></a>
		</div>
		<b class="icon_t" id="icon1_t">방으로</b>

		<div class="icon" id="icon2">
			<a href="../game.jsp?m_id=<%=Map.m_id%>&mode=map"><img
				src="img/map.png" id="mapimg"></a>
		</div>
		<b class="icon_t" id="icon2_t">지도</b>

		<div class="icon" id="icon3">
			<a href="../game.jsp?m_id=<%=Map.m_id%>&mode=bag"><img
				src="img/bag.png" id="bagimg"></a>
		</div>
		<b class="icon_t" id="icon3_t">가방</b>

		<div class="icon" id="icon4">
			<a href="../character.jsp"><img src="../img/charac.png"></a>
		</div>
		<b class="icon_t" id="icon4_t">캐릭터</b>

	</div>
	<div id="s_banner_bot">
		<%=mem.loginInfo()%>
	</div>
</body>
</html>