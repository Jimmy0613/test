<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.db.DataSelect"%>
<%@page import="java.util.ArrayList"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>지난 기록</title>
<%
String styleCss = application.getRealPath("/css/common.css");
File style= new File(styleCss);
Date lastModifiedStyle = new Date(style.lastModified());
SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMddhhmmssSSS");

DataSelect ds = new DataSelect();
%>
<link rel="stylesheet" href="css/popup.css?ver=<%=fmt.format(lastModifiedStyle)%>">
</head>
<body>
<%
Log log = new Log();
String where = "order by sm_num";
ArrayList<String> msgs = ds.dbExecuteQueryStrArr("msg", "log", where);
for(String s: msgs){
	out.println(s);%><br><%
}
%>
</body>
</html>