<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%
	DataUpdate du = new DataUpdate();
	if (Charac.story < 6) {
		du.sendSystemMsg("❌ ''이야기 <6> 지도''를 먼저 완료해야 합니다.","bad");
	%>
	<jsp:forward page="game.jsp">
		<jsp:param value="normal" name="mode" />
		<jsp:param value="<%=Map.m_id%>" name="m_id" />
	</jsp:forward>
	<%
	} else {
	%>
	<jsp:forward page="game.jsp">
		<jsp:param value="move" name="mode" />
		<jsp:param value="m_1" name="m_id" />
	</jsp:forward>
	<%
	}
	%>
</body>
</html>