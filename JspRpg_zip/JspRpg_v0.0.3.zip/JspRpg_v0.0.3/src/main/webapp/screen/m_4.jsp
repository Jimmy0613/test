<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.db.Member"%>
<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="../css/m_4.css">

</head>
<body>
	<%
	Map map = new Map();
	Charac ch = new Charac();
	DataUpdate du = new DataUpdate();
	Log log = new Log();
	Map.m_id = request.getParameter("m_id");
	map.loadMap();
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n">
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.m_n%>&mode=move'"><%=map.getName(Map.m_n)%></button>
	</div>
	<div id="w"></div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map.move();
		case "normal":
			if (Charac.story < 5) {
		%>
		<div id="bag">
			<img src="img/bag.png" id="bagimg">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action1'">살펴보기</button>
		</div>
		<%
		}
		%>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			Charac.story = 5;
			Charac.exp += 5;
			Charac.map_open = 4;
			du.sendSystemMsg(Charac.name + " \"가방이다! \"","speech");
			du.sendSystemMsg("👜 이제 가방을 사용할 수 있습니다.","good");
			du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +5)","story");
			du.sendSystemMsg("🏃‍♂️ 새로운 지역이 열렸습니다. (거실)","map");
		%>
		<div id="player">
			<img src="img/humanbag.png" id="playerimg2">
		</div>
		<%
		break;

		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e"></div>
	<div id="s"></div>
</body>
</html>