<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.db.Member"%>
<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="../css/m_5.css">

</head>
<body>
	<%
	Map map_i = new Map();
	Charac c = new Charac();
	DataUpdate du = new DataUpdate();
	Log l = new Log();
	Map.m_id = request.getParameter("m_id");
	map_i.loadMap();
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w">
		<button id="we_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.m_w%>&mode=move'"><%=map_i.getName(Map.m_w)%></button>
	</div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
		%>
		<div id="desk">
			<img src="img/desk.png" id="deskimg">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action1'">서랍
				열기</button>
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			if (Charac.story < 6) {
				Charac.story = 6;
				Charac.exp += 5;
				l.turn();
				du.sendSystemMsg("[ " + Log.turnCount + " ] 서랍을 열었습니다.", "normal");
				du.sendSystemMsg(Charac.name + " \"지도다! \"", "speech");
				du.sendSystemMsg("👜 이제 지도를 사용할 수 있습니다.", "good");
				du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +5)", "story");
				du.sendSystemMsg("💡 ''방으로'' 아이콘을 누르면 즉시 \'나의 방\'으로 이동할 수 있습니다.", "tip");
		%>
		<div id="desk">
			<img src="img/desk.png" id="deskimg">
		</div>
		<div id="player">
			<img src="img/humanmap.png" id="playerimg2">
		</div>
		<%
		} else {
		l.turn();
		du.sendSystemMsg("[ " + Log.turnCount + " ] 서랍을 열었습니다. 아무것도 없습니다.", "normal");
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="normal" name="mode" />
			<jsp:param value="<%=Map.m_id%>" name="m_id" />
		</jsp:forward>
		<%
		}
		break;

		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e"></div>
	<div id="s">
		<%
		if (Charac.story >= 7) {
		%>
		<button id="ns_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.m_s%>&mode=move'"><%=map_i.getName(Map.m_s)%></button>
		<%
		}
		%>
	</div>
</body>
</html>