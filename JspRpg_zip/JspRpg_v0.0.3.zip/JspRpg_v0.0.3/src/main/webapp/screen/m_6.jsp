<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@page import="com.cre.w.rpg.game.Map"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="../css/m_6.css">

</head>
<body>
	<%
	Map map_i = new Map();
	Charac c = new Charac();
	DataUpdate du = new DataUpdate();
	Log l = new Log();
	Map.m_id = request.getParameter("m_id");
	map_i.loadMap();
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n">
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.m_n%>&mode=move'"><%=map_i.getName(Map.m_n)%></button>
	</div>
	<div id="w"></div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
			if (Charac.story < 8) {
				du.sendSystemMsg(Charac.name + " \"돈이다! \"", "speech");
		%>
		<div id="sp1">
			<img src="img/sp_m6_1.jpg">
		</div>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player">
			<img src="img/human6.jpg">
		</div>
		<div id="coin">
			<img src="img/coin.jpg">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action1'">줍기</button>
		</div>

		<%
		} else if (Charac.map_open < 6) {
		du.sendSystemMsg(Charac.name + " \"깜짝이야! 누구세요?! \"", "speech");
		%>
		<div id="sp3">
			<img src="img/sp_m6_3.jpg">
		</div>
		<div id="wall2">
			<img src="img/wallhuman.png">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action2'">다가가기</button>
		</div>
		<div id="player">
			<img src="img/human6.jpg">
		</div>

		<%
		} else {
		%>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player">
			<img src="img/humannormal.jpg">
		</div>
		<%
		}
		break;
		case "action1":
		Charac.story = 8;
		Charac.exp += 5;
		Charac.coin += 5;
		du.sendSystemMsg(Charac.name + " \"아싸! \"", "speech");
		du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +5, 금화 +5)", "story");
		%>
		<div id="sp2">
			<img src="img/sp_m6_2.jpg">
		</div>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player2">
			<img src="img/humancoin.png">
		</div>
		<%
		break;
		case "action2":
			Charac.map_open = 6;
			du.sendSystemMsg(Charac.name + " \"사라졌다?! \"", "speech");
			du.sendSystemMsg("🏃‍♂️ 새로운 지역이 열렸습니다. (우리집 앞)", "map");
		%>

		<div id="sp4">
			<img src="img/sp_m6_4.jpg">
		</div>
		<div id="wall">
			<img src="img/wall.png">
		</div>
		<div id="player">
			<img src="img/humansurprised.jpg">
		</div>
		<%
		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e"></div>
	<div id="s"></div>
</body>
</html>