<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.db.Member"%>
<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="../css/m_1.css">
</head>
<body>
	<%
	Map map_i = new Map();
	Charac ch_i = new Charac();
	DataUpdate du = new DataUpdate();
	Log l = new Log();
	map_i.loadMap();
	Map.m_id = request.getParameter("m_id");
	String mode = request.getParameter("mode");
	%>

	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n">
		<%
		if (Charac.map_open >= 1) {
		%>
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.m_n%>&mode=move'"><%=map_i.getName(Map.m_n)%></button>
		<%
		}
		%>
	</div>
	<div id="w"></div>
	<!---------------------------------------------------스크린 --------------------------------------------------->
	<div id="screen_c">
		<%
		String msg = "";
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action1'">잠자기</button>
			<img src="img/bed.jpg" id="bedimg">
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			if (Charac.power == Charac.powerFull) {
				du.sendSystemMsg(Charac.name + " \"지금은 잘 필요가 없는 것 같은데?\"","speech");
				if (Charac.story < 0) {
			Charac.story = 0;
			Charac.map_open = 1;
			Charac.exp += 5;
			du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +5)","story");
			du.sendSystemMsg("💡 ''지난 이야기 보기''를 통해 완료한 이야기 목록을 볼 수 있습니다.","tip");
			du.sendSystemMsg("🏃‍♂️ 새로운 지역이 열렸습니다. (복도)","map");
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="normal" name="mode" />
			<jsp:param value="<%=Map.m_id%>" name="m_id" />
		</jsp:forward>
		<%
		}
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action1'">잠자기</button>
			<img src="img/bed.jpg" id="bedimg">
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		} else {
		l.turn();
		du.sendSystemMsg("[ " + Log.turnCount + " ] 🛏 침대에 누웠습니다..","normal");
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action2'">일어나기</button>
			<img src="img/sleeping.jpg" id="bedimg">
		</div>
		<%
		}
		break;
		case "action2":
		l.turn();
		Charac.power = Charac.powerFull;
		ch_i.updateCharacter();
		du.sendSystemMsg("[ " + Log.turnCount + " ] 힘을 회복했습니다.","normal");
		if (Charac.story < 3) {
		Charac.story = 3;
		Charac.map_open = 2;
		Charac.exp += 10;
		du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +10)","story");
		du.sendSystemMsg("🏃‍♂️ 새로운 지역이 열렸습니다. (주방)","map");
		}
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action3" name="mode" />
			<jsp:param value="<%=Map.m_id%>" name="m_id" />
		</jsp:forward>
		<%
		case "action3":
		%>
		<div id="bed">
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action1'">잠자기</button>
			<img src="img/bed.jpg" id="bedimg">
		</div>
		<div id="player">
			<img src="img/humanPower.png" id="playerimg">
		</div>
		<%
		break;
		
		}
		%>
	</div>
	<!----------------------------------------------------------------------------------------------------------------->
	<div id="e"></div>
	<div id="s"></div>
</body>
</html>