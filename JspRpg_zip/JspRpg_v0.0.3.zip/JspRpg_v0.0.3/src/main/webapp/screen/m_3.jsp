<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="../css/m_3.css">

</head>
<body>
	<%
	Map map_i = new Map();
	DataUpdate du = new DataUpdate();
	Log log = new Log();
	
	Map.m_id = request.getParameter("m_id");
	map_i.loadMap();
	String mode = request.getParameter("mode");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w"></div>
	<!------------------스크린 ------------------>
	<div id="screen_c">
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
		%>
		<div id="fridge">
			<img src="img/fridge.jpg" id="fridgeimg">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action1'">열기</button>
		</div>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
			if (Charac.story < 4) {
				Charac.story = 4;
				Charac.exp += 5;
				Charac.map_open = 3;
				log.turn();
				du.sendSystemMsg("[ " + Log.turnCount + " ] 냉장고를 열었습니다.","normal");
				du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +5)","story");
				du.sendSystemMsg("🎉 새로운 지역이 열렸습니다. (다용도실)","map");
				du.sendSystemMsg("💡 냉장고에는 음식 아이템을 넣을 수 있습니다.","tip");
			}
		%>
		<button id="f_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=normal'">닫기</button>
		<div id="f_open">
			<div id="content_t">냉장고</div>
			<div id="content_t">가방(음식)</div>
			<div id="f_inside">
				<div id="item">1</div>
				<div id="item">2</div>
				<div id="item">3</div>
				<div id="item">4</div>
				<div id="item">5</div>
				<div id="item">6</div>
				<div id="item">1</div>
				<div id="item">2</div>
				<div id="item">3</div>
				<div id="item">4</div>
				<div id="item">5</div>
				<div id="item">6</div>
			</div>
			<div id="f_b_food">
				<%@include file="bag_food.jsp"%>
			</div>
		</div>
		<%
		break;

		}
		%>
	</div>
	<!------------------스크린 ------------------>
	<div id="e">
		<%
		if (Charac.map_open >= 2 && Charac.story >= 4) {
		%>
		<button id="we_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.m_e%>&mode=move'"><%=map_i.getName(Map.m_e)%></button>
		<%
		}
		%>
	</div>
	<div id="s">
		<%
		if (Charac.map_open >= 3) {
		%>
		<button id="ns_btn"
			onclick="location.href='../game.jsp?m_id=<%=Map.m_s%>&mode=move'"><%=map_i.getName(Map.m_s)%></button>
		<%
		}
		%>
	</div>
</body>
</html>