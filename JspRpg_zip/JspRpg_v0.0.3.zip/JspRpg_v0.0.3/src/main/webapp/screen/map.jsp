<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="../css/map.css">
</head>
<body>
	<%
	DataUpdate du = new DataUpdate();
	Log l = new Log();
	if (Charac.story < 6) {
		du.sendSystemMsg("❌ 지도를 획득한 후 이용할 수 있습니다.", "bad");
	%>
	<jsp:forward page="game.jsp">
		<jsp:param value="normal" name="mode" />
		<jsp:param value="<%=Map.m_id%>" name="m_id" />
	</jsp:forward>
	<%
	} else {
		if(Charac.story<7){
			Charac.story = 7;
			Charac.exp += 5;
			Charac.map_open = 5;
			du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +5)","story");
			du.sendSystemMsg("🏃‍♂️ 새로운 지역이 열렸습니다. (마당)","map");
		}
	l.turn();
	du.sendSystemMsg("[ " + Log.turnCount + " ] 지도를 펼쳤습니다.", "normal");
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w"></div>
	<!---------------------------------------------------스크린 --------------------------------------------------->
	<div id="screen_c">
		<button id="m_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.m_id%>&mode=normal'">접기</button>
		<div id="map_open">
			<%@include file="map_house.jsp" %>
		</div>
	</div>
	<!----------------------------------------------------------------------------------------------------------------->
	<div id="e"></div>
	<div id="s"></div>
	<%
	}
	%>
</body>
</html>