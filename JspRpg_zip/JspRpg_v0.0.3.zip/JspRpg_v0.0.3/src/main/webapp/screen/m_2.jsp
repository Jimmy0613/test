<%@page import="com.cre.w.rpg.game.Log"%>
<%@page import="com.cre.w.rpg.game.Map"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.util.Date"%>
<%@page import="java.io.File"%>
<%@page import="com.cre.w.rpg.db.DataUpdate"%>
<%@page import="com.cre.w.rpg.game.Charac"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<link rel="stylesheet" href="../css/m_2.css">

</head>
<body>
	<%
	Charac ch_i = new Charac();
	DataUpdate du = new DataUpdate();
	Map map_i = new Map();
	Map.m_id = request.getParameter("m_id");
	map_i.loadMap();
	String mode = request.getParameter("mode");
	Log log = new Log();
	%>
	<div id="t">
		<%@include file="../title.jsp"%>
	</div>
	<div id="n"></div>
	<div id="w">
		<%
		if (Charac.map_open >= 2) {
		%>
		<button id="we_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.m_w%>&mode=move'"><%=map_i.getName(Map.m_w)%></button>
		<%
		}
		%>
	</div>
	<div id="screen_c">
		<!------------------스크린 ------------------>
		<%
		switch (mode) {
		case "move":
			map_i.move();
		case "normal":
			if (Charac.story < 1) {
				du.sendSystemMsg(Charac.name + " \"으악 쥐다!\"", "speech");
				log.turn();
				du.sendSystemMsg("[ " + Log.turnCount + " ] 쥐를 보고 놀라 힘이 빠졌습니다. (힘 -2)", "normal");
				Charac.power -= 2;
				Charac.story = 1;
				ch_i.updateCharacter();
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action1" name="mode" />
			<jsp:param value="<%=Map.m_id%>" name="m_id" />
		</jsp:forward>
		<%
		} else if (Charac.story < 2) {
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action1" name="mode" />
			<jsp:param value="<%=Map.m_id%>" name="m_id" />
		</jsp:forward>
		<%
		}
		%>
		<div id="player">
			<img src="img/humannormal.jpg" id="playerimg">
		</div>
		<%
		break;
		case "action1":
		%><div id="player">
			<img src="img/humansurprised.jpg" id="playerimg">
		</div>
		<div id="mice">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button
				onclick="location.href='../game.jsp?m_id=<%=Map.m_id%>&mode=action2'">쫓아내기</button>
			<img src="img/mice.png" id="miceimg">
		</div>
		<%
		break;
		case "action2":
			if (Charac.story < 2) {
				log.turn();
				Charac.power -= 1;
				du.sendSystemMsg("[ " + Log.turnCount + " ] 쥐가 도망갔습니다. (힘 -1)", "normal");
				Charac.story = 2;
				Charac.exp += 20;
				du.sendSystemMsg("🎉 새로운 이야기를 완료했습니다. (경험치 +20)", "story");
				du.sendSystemMsg("💡 침대에서 자면 힘을 회복할 수 있습니다.", "tip");
			}
		%>
		<jsp:forward page="../game.jsp">
			<jsp:param value="action3" name="mode" />
			<jsp:param value="<%=Map.m_id%>" name="m_id" />
		</jsp:forward>
		<%
		case "action3":
		%>
		<div id="player">
			<img src="img/humanactive.jpg" id="playerimg">
		</div>
		<%
		break;

		}
		%>
	</div>
	<!---------------------------------------------------------------------------------------------------------------------------->
	<div id="e">
		<%
		if (Charac.map_open >= 4) {
		%>
		<button id="we_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.m_e%>&mode=move'"><%=map_i.getName(Map.m_e)%></button>
		<%
		}
		%>
	</div>
	<div id="s">
		<%
		if (Charac.story >= 2) {
		%>
		<button id="ns_btn"
			onclick="location.href='game.jsp?m_id=<%=Map.m_s%>&mode=move'"><%=map_i.getName(Map.m_s)%></button>
		<%
		}
		%>
	</div>
</body>
</html>